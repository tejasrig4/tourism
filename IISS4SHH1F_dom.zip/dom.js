document.getElementById("clickButton");

function clickIt() {
    document.getElementById("changeHeading").textContent = 'Dynamic Webpage';
    document.getElementById("changeHeading").style.color = "blue";
}
document.getElementById('updateButton');

function update() {
    updateButton.style.background = "red"
    document.getElementById("updateHead").textContent = 'Gudavalli Tejasri';
    updateHead.style.color = "green";
}